﻿
public class Shared
{
//Создание массива
public static int [] CreateArray(int size)
{return new int[size];
}

//Ввод данных
public static int Input( string text)
{Console.WriteLine(text + " ");
 return Convert.ToInt32(Console.ReadLine());
 
}


//генерация данных
public static int Gen()
{ return Random.Shared.Next(0,25 );
}

//заполнение данных
public static void FillByRandom(int[] array)
{
int length = array.Length;
int index =0;
while (index<length)
   {array[index] = Gen();
   index ++ ;
   }
}

//печать 
public static void Print1(int[] array)
  {
    int length = array.Length;
    int index = 0;
    while (index < length)
    { Console.Write(array[index] + " ");
      index++;
    }
    System.Console.WriteLine();
  }

//Ввод числа
public static int InputValue( string text)
{Console.WriteLine(text + " ");
 return Convert.ToInt32(Console.ReadLine());
 
}



//
public static void Arr()
{
int count = Input("Введите размер массива");
int[] numbers = CreateArray(count);
Print1(numbers);
Console.WriteLine("Сформированный массив: ");
FillByRandom(numbers);
Print1(numbers);
}


//считаем(x2-x1)^2
public static int S (int x1, int x2)
{return (x2-x1)*(x2-x1);
}

}






