/*
Задача 19
Напишите программу, которая принимает на вход пятизначное число и проверяет, является ли оно палиндромом.
14212 -> нет
12821 -> да
23432 -> да
*/


using static Shared;
Console.Clear();
string Value = Convert.ToString(InputValue("Введите пятизначное число: "));
int l = Value.Length;
if (l == 5)
    {   int[] num = CreateArray(l);
        int index = 0; 
        int i =0;
        int z= 0;
        
        foreach (char c in Value)
        {
        num[index] = Convert.ToInt32(c - '0');
        index++;
        }
        
        while (i<l/2)
          { 
           if (num[i]==num[l-1-i] )
            {
             z = z+1;
            }
            i++;

          }
          if (z == l/2)
           Console.WriteLine("Число " + Value + "  - полиндром!");
          else 
            Console.WriteLine("Число " + Value + "  - не является полиндромом!");


    }
else {
    Console.WriteLine("Нужно ввести пятизначное число!"); 
    goto Label1;}


Label1:
Console.WriteLine("------Задача2:------"); 

/*
Задача 21
Напишите программу, которая принимает на вход координаты двух точек и находит расстояние между ними в 3D пространстве.
A (3,6,8); B (2,1,-7), -> 15.84
A (7,-5, 0); B (1,-1,9) -> 11.53
*/
int count1 = 3;
int[] masA=CreateArray(count1);
int[] masB=CreateArray(count1);
FillByRandom(masA);
FillByRandom(masB);
Console.WriteLine("Координаты т.A:");
Print1(masA);
Console.WriteLine("Координаты т.B:");
Print1(masB);
int k = 0;
int summa = 0;
while (k<count1)
  {summa = summa + S(masB[k],masA[k]);
  k++;
  }
 Console.WriteLine("Расстояние между т.А и т.B: " + Math.Round(Math.Sqrt(summa),2)); 
/*
 Задача 23

Напишите программу, которая принимает на вход число (N) и выдаёт таблицу кубов чисел от 1 до N.
3 -> 1, 8, 27
5 -> 1, 8, 27, 64, 125
*/
int val = InputValue("Введите число: ");
int ii=1;
while ( ii<= val)
{ Console.Write(Math.Pow(ii,3)+ " ");
ii++;
}